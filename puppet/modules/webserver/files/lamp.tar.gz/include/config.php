<?php

$config = array(
    'driver' => 'mysql',
    'host'   => 'localhost',
    'dbname' => 'dexter500',
    'user'   => 'admin',
    'password' => '4linux'

);